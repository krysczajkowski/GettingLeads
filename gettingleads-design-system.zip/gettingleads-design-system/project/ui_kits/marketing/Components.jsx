/* GettingLeads marketing — shared UI primitives
 * Components.jsx — Button, Eyebrow, Logo, common icons.
 * Exported to window for cross-file scope sharing.
 */

const { useState, useEffect, useRef } = React;

/* ---------- Icons (Lucide, hand-traced — 24×24, stroke 1.5) ---------- */
const Icon = {
  ArrowRight: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  ArrowUpRight: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17 17 7M8 7h9v9"/></svg>,
  Check: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m20 6-11 11-5-5"/></svg>,
  Search: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>,
  Target: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>,
  Radar: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19.07 4.93A10 10 0 1 1 6.86 3.49"/><path d="M21 3v6h-6"/><path d="M12 12 2 22"/></svg>,
  Bell: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>,
  Trend: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 5-5"/></svg>,
  Filter: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M6 12h12M10 18h4"/></svg>,
  Send: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4 20-7Z"/></svg>,
  Zap: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2 3 14h8l-1 8 10-12h-8l1-8Z"/></svg>,
  Users: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="8" r="4"/><path d="M1 21a8 8 0 0 1 16 0"/><path d="M17 4a4 4 0 0 1 0 8"/><path d="M23 21a8 8 0 0 0-4-7"/></svg>,
  Sparkles: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>,
  Clock: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  Lock: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>,
  Inbox: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 13h5l2 3h4l2-3h5"/><path d="M3 13V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7"/><path d="M3 13v5a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5"/></svg>,
};

/* ---------- Logo (mark + wordmark, inline SVG for crispness) ---------- */
function GLLogo({ size = 24, inverted = false }) {
  const c = inverted ? '#FFFFFF' : '#15B36C';
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-label="GettingLeads">
      <circle cx="16" cy="16" r="13.5" stroke={c} strokeWidth="1.6" opacity={inverted ? 0.4 : 0.25}/>
      <circle cx="16" cy="16" r="8.5"  stroke={c} strokeWidth="1.6" opacity={inverted ? 0.65 : 0.5}/>
      <path d="M16 16 L16 2.5 A13.5 13.5 0 0 1 27.7 9.25 Z" fill={c} fillOpacity={inverted ? 0.25 : 0.18}/>
      <path d="M16 2.5 A13.5 13.5 0 0 1 27.7 9.25" stroke={c} strokeWidth="1.8" strokeLinecap="round"/>
      <circle cx="16" cy="16" r="2.4" fill={c}/>
      <circle cx="23.4" cy="7.4" r="2.1" fill={c}/>
    </svg>
  );
}

/* ---------- Button ---------- */
function GLButton({ variant = 'primary', size, children, icon, iconRight, as = 'button', ...rest }) {
  const Comp = as;
  const cls = `gl-btn gl-btn--${variant}${size ? ` gl-btn--${size}` : ''}`;
  return (
    <Comp className={cls} {...rest}>
      {icon}{children}{iconRight}
    </Comp>
  );
}

/* ---------- Eyebrow (the pill-shaped kicker label) ---------- */
function GLEyebrow({ children, withDot = true }) {
  return (
    <span className="gl-eyebrow">
      {withDot && <span className="dot"/>}
      {children}
    </span>
  );
}

/* ---------- Section head ---------- */
function GLSectionHead({ eyebrow, title, sub, align = 'center' }) {
  return (
    <div className={`gl-shead${align === 'left' ? ' gl-shead--left' : ''}`}>
      {eyebrow && <GLEyebrow>{eyebrow}</GLEyebrow>}
      <h2>{title}</h2>
      {sub && <p>{sub}</p>}
    </div>
  );
}

/* ---------- Number ticker — counts up on mount ---------- */
function NumTicker({ to, duration = 1200, format = (n) => Math.round(n) }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / duration);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(eased * to);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <>{format(val)}</>;
}

/* ---------- Score chip ---------- */
function ScoreChip({ score }) {
  const band = score >= 80 ? 'hot' : score >= 50 ? 'warm' : 'cool';
  const bg   = band === 'hot' ? 'var(--green-50)'  : band === 'warm' ? 'var(--warn-50)'  : 'var(--bg-2)';
  const fg   = band === 'hot' ? 'var(--green-700)' : band === 'warm' ? 'var(--warn-700)' : 'var(--fg-3)';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'baseline', gap: 3,
      padding: '4px 9px', borderRadius: 'var(--r-sm)',
      fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 12,
      background: bg, color: fg,
    }}>
      {score}<span style={{ fontSize: 10, opacity: 0.5, fontWeight: 400 }}>/100</span>
    </span>
  );
}

/* ---------- Lead card (used on hero + dashboard preview) ---------- */
function LeadCard({ lead, animateIn = false, delay = 0 }) {
  if (!lead) return null;
  const tags = lead.tags || [];
  return (
    <div
      className={animateIn ? 'fade-up' : ''}
      style={{
        animationDelay: animateIn ? `${delay}ms` : undefined,
        background: '#fff', border: '1px solid var(--line-1)',
        borderRadius: 'var(--r-md)', padding: 14,
        boxShadow: 'var(--shadow-card)',
        display: 'flex', flexDirection: 'column', gap: 8,
      }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 28, height: 28, borderRadius: '50%',
            background: 'var(--green-50)', color: 'var(--green-700)',
            border: '1px solid var(--green-100)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600,
          }}>{lead.initials}</div>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15 }}>
            <span style={{ fontSize: 13, fontWeight: 500 }}>{lead.name}</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>{lead.group}</span>
          </div>
        </div>
        <ScoreChip score={lead.score}/>
      </div>
      <p style={{ margin: 0, fontSize: 13, lineHeight: 1.5, color: 'var(--fg-2)' }}>
        {lead.before}
        <mark style={{ background: 'var(--green-50)', color: 'var(--green-800)', padding: '0 2px' }}>{lead.highlight}</mark>
        {lead.after}
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', gap: 4 }}>
          {tags.map((t, ti) => (
            <span key={`${t}-${ti}`} style={{
              fontSize: 11, padding: '2px 8px', borderRadius: 'var(--r-pill)',
              background: 'var(--bg-2)', color: 'var(--fg-3)',
            }}>{t}</span>
          ))}
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>{lead.when}</span>
      </div>
    </div>
  );
}

Object.assign(window, { Icon, GLLogo, GLButton, GLEyebrow, GLSectionHead, NumTicker, ScoreChip, LeadCard });
