# GettingLeads — Marketing UI kit

A high-fidelity recreation of the GettingLeads marketing site. The brief was: white background, simple, modern, lots of animations. Everything below leans into the **signal-from-noise** brand metaphor — radar sweep behind the hero, live-updating lead feed, scanning gradient on the product mock, counters that animate up on mount.

## What's in here

- `index.html` — composes the full landing page.
- `styles.css` — page-level styles. Imports `../../colors_and_type.css` for tokens.
- `Components.jsx` — Logo, Button, Eyebrow, SectionHead, NumTicker, ScoreChip, LeadCard, Icon set.
- `Top.jsx` — `Nav`, `Hero` (with live `HeroFeed`), `TrustMarquee`.
- `Mid.jsx` — `HowItWorks` (with three live step demos), `DashboardPreview` (animated mock of the product), `Features`.
- `Bottom.jsx` — `Stats`, `Pricing`, `FinalCTA`, `Footer`.

## Sections (top → bottom)

1. **Sticky nav** — 64px, white with backdrop blur, signal-green pulsing dot in the "Live · beta" eyebrow.
2. **Hero** — split layout, big serif-italic accent ("while you sleep."), live lead feed on the right that gains a new card every ~4s.
3. **Trust marquee** — infinite horizontal scroll of group names being monitored, masked at the edges.
4. **How it works** — three steps, each with a live demo inside the card (typewriter, checklist, ranked list).
5. **Dashboard preview** — three-column product mock (sidebar / lead list / detail) with a scan-line gradient sweeping across it.
6. **Stats band** — four counters that tick up on mount.
7. **Features grid** — 3×2 grid in a single bordered card.
8. **Pricing** — three tiers, "Team" is featured (black border, popular tag).
9. **Final CTA** — dark ink card with a decorative radar in the corner.
10. **Footer** — standard 4-column.

## Motion principles applied

- All entrances use `--ease-out` with delays of 80–400ms (see `.fade-up--d1..d5`).
- Counters use easeOutCubic for 1.2s.
- The radar sweep is a `conic-gradient` rotated with a CSS animation — no JS.
- Marquee uses a duplicated track + `translateX(-50%)` for a seamless loop.
- Card hovers lift 1px and bump shadow tier (`--shadow-card` → `--shadow-card-hover`).

## Open questions

- Hero illustration: the live feed is fully synthetic. If you have real product screenshots, swap them in.
- Pricing numbers are placeholders ($49 / $199 / Custom).
- "Customers" link in nav is dead — populate when you have logos.
