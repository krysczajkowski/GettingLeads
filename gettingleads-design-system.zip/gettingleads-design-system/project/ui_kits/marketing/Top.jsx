/* Marketing — top of page (Nav + Hero + Trust marquee) */

function Nav() {
  return (
    <nav className="gl-nav">
      <div className="container gl-nav__inner">
        <div className="gl-nav__left">
          <a href="#" className="gl-nav__logo">
            <GLLogo size={26}/> GettingLeads
          </a>
          <div className="gl-nav__links">
            <a href="#product">Product</a>
            <a href="#how">How it works</a>
            <a href="#pricing">Pricing</a>
            <a href="#">Customers</a>
            <a href="#">Changelog</a>
          </div>
        </div>
        <div className="gl-nav__right">
          <GLButton variant="ghost" size="sm">Sign in</GLButton>
          <GLButton variant="primary" size="sm" iconRight={<Icon.ArrowRight/>}>Start free trial</GLButton>
        </div>
      </div>
    </nav>
  );
}

/* Floating animated lead-cards beside the hero copy */
function HeroFeed() {
  // Initial set + "new lead" that animates in after a few seconds
  const initial = [
    { id: 1, initials: 'MR', name: 'Marisa R.',  group: 'Shopify Founders · 47k', score: 94, when: '4m ago',
      before: '"Anyone know a good ', highlight: '3PL for skincare brands', after: ' shipping out of CA? Currently doing 800 orders/month."',
      tags: ['fulfillment', 'us'], delay: 80 },
    { id: 2, initials: 'JT', name: 'Jordan T.',  group: 'SaaS Operators · 22k',  score: 71, when: '18m ago',
      before: '"Looking for recs — what\'s everyone using for ', highlight: 'cold email warmup', after: ' these days?"',
      tags: ['cold-email', 'saas'], delay: 200 },
    { id: 3, initials: 'AK', name: 'Aria K.',    group: 'DTC CMOs · 14k',         score: 88, when: '32m ago',
      before: '"Have a $40k/mo Meta budget and need a new ', highlight: 'agency for creative testing', after: '. DM-friendly recs?"',
      tags: ['agency', 'meta'], delay: 320 },
  ];

  const [feed, setFeed] = useState(initial);
  const [newCount, setNewCount] = useState(0);

  useEffect(() => {
    const incoming = [
      { id: 100, initials: 'DV', name: 'Devon V.',  group: 'Agency Owners · 19k',  score: 91, when: 'just now',
        before: '"My CRM is a graveyard. Anyone tried ', highlight: 'an AI tool that finds leads', after: ' in groups for you?"',
        tags: ['intent', 'hot'] },
      { id: 101, initials: 'PS', name: 'Priya S.',  group: 'Ecom Insiders · 31k',  score: 83, when: 'just now',
        before: '"We sell to ', highlight: 'plant-based food brands', after: '. Where are they hanging out these days?"',
        tags: ['icp', 'food'] },
    ];
    let i = 0;
    const id = setInterval(() => {
      if (i >= incoming.length) { clearInterval(id); return; }
      setFeed(f => [{ ...incoming[i], _new: true }, ...f].slice(0, 4));
      setNewCount(n => n + 1);
      i++;
    }, 4200);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ position: 'relative' }}>
      {/* Live label */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 12, padding: '0 4px',
      }}>
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-3)',
          textTransform: 'uppercase', letterSpacing: '0.08em',
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            background: 'var(--brand)', boxShadow: '0 0 0 3px rgba(21,179,108,0.18)',
          }}/>
          Live · matching now
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>
          <NumTicker to={284 + newCount} format={n => Math.round(n).toLocaleString()}/> leads today
        </span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {feed.map((l, i) => (
          <LeadCard key={`${l.id}-${i}`} lead={l} animateIn delay={l._new ? 0 : (l.delay ?? i * 80)}/>
        ))}
      </div>
    </div>
  );
}

function Hero() {
  return (
    <header className="gl-hero">
      <div className="gl-hero__bg"/>
      <div className="container gl-hero__grid">
        <div>
          <div className="fade-up"><GLEyebrow>Now in public beta · v1.2</GLEyebrow></div>
          <h1 className="gl-hero__title fade-up fade-up--d1">
            Find leads in Facebook groups <span className="accent">while you sleep.</span>
          </h1>
          <p className="gl-hero__sub fade-up fade-up--d2">
            GettingLeads monitors public groups around the clock, scores every post against your buyer,
            and delivers the ones worth replying to — straight to your inbox.
          </p>
          <div className="gl-hero__ctas fade-up fade-up--d3">
            <GLButton variant="primary" size="lg" iconRight={<Icon.ArrowRight/>}>Start free 14-day trial</GLButton>
            <GLButton variant="secondary" size="lg">See a live demo</GLButton>
          </div>
          <div className="gl-hero__note fade-up fade-up--d4">
            <span><Icon.Check/> No credit card</span>
            <span><Icon.Check/> Setup in 3 minutes</span>
            <span><Icon.Check/> Cancel any time</span>
          </div>
        </div>
        <div className="fade-up fade-up--d2">
          <HeroFeed/>
        </div>
      </div>
    </header>
  );
}

/* ---------- Trust band: scrolling group names ---------- */
function TrustMarquee() {
  const groups = [
    { name: 'Shopify Founders',        count: '47k' },
    { name: 'SaaS Operators',          count: '22k' },
    { name: 'DTC CMOs',                count: '14k' },
    { name: 'Agency Owners',           count: '19k' },
    { name: 'Ecom Insiders',           count: '31k' },
    { name: 'B2B SaaS Founders',       count: '28k' },
    { name: 'Indie Hackers',           count: '54k' },
    { name: 'CFO Network',             count: '9k'  },
    { name: 'PLG Collective',          count: '12k' },
    { name: 'Cold Email Wizards',      count: '8k'  },
  ];
  const all = [...groups, ...groups]; // duplicate for seamless loop

  return (
    <section className="gl-trust">
      <div className="container">
        <div className="gl-trust__label">Currently monitoring 1,847 groups · 12.6M members</div>
        <div className="gl-marquee">
          <div className="gl-marquee__track">
            {all.map((g, i) => (
              <span key={i} className="gl-marquee__item">
                <Icon.Users/>
                {g.name}
                <span className="count">{g.count}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Nav, Hero, TrustMarquee });
