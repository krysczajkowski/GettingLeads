/* Marketing — bottom: Stats, Pricing, Final CTA, Footer */

function Stats() {
  return (
    <section className="section section--tight">
      <div className="container">
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 0, border: '1px solid var(--line-1)',
          borderRadius: 'var(--r-lg)', overflow: 'hidden', background: '#fff',
        }}>
          {[
            { num: 1847, label: 'groups monitored',  fmt: n => Math.round(n).toLocaleString() },
            { num: 12.6, label: 'million members reached', suffix: 'M', fmt: n => n.toFixed(1) },
            { num: 284,  label: 'leads scored / day · avg', fmt: n => Math.round(n).toLocaleString() },
            { num: 87,   label: 'reply rate on top decile', suffix: '%', fmt: n => Math.round(n) },
          ].map((s, i) => (
            <div key={i} style={{
              padding: '32px 28px',
              borderRight: i < 3 ? '1px solid var(--line-1)' : 'none',
              display: 'flex', flexDirection: 'column', gap: 4,
            }}>
              <div style={{
                fontFamily: 'var(--font-display)', fontWeight: 600,
                fontSize: 44, letterSpacing: '-0.025em', lineHeight: 1,
                color: 'var(--fg-1)',
              }}>
                <NumTicker to={s.num} format={s.fmt}/>{s.suffix && <span>{s.suffix}</span>}
              </div>
              <div style={{ fontSize: 13, color: 'var(--fg-3)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const tiers = [
    {
      name: 'Solo',
      price: 49, per: '/ month',
      desc: 'For founders and freelancers monitoring a handful of communities.',
      features: ['5 groups monitored', '100 leads / day', '1 buyer profile', 'Daily digest email', 'CSV export'],
      cta: 'Start free trial',
    },
    {
      name: 'Team',
      price: 199, per: '/ month',
      desc: 'For sales teams of 3–10 who live in their lead inbox.',
      features: ['25 groups monitored', '1,000 leads / day', '5 buyer profiles', 'Suggested replies', 'Saved views + shared queues', 'Slack & email notifications'],
      cta: 'Start free trial',
      featured: true,
    },
    {
      name: 'Scale',
      price: 'Custom', per: '',
      desc: 'For agencies and orgs running outbound at scale.',
      features: ['Unlimited groups', 'Unlimited leads', 'Unlimited buyer profiles', 'API & webhooks', 'CRM integrations', 'Dedicated success manager'],
      cta: 'Talk to sales',
    },
  ];
  return (
    <section className="section" id="pricing">
      <div className="container">
        <GLSectionHead
          eyebrow="Pricing"
          title="Pay for the leads, not the seats."
          sub="14-day free trial on every plan. Cancel any time. No annual lock-in."
        />
        <div className="gl-pricing">
          {tiers.map((t, i) => (
            <div key={i} className={`gl-price${t.featured ? ' gl-price--featured' : ''}`}>
              {t.featured && <span className="featured-tag">Most popular</span>}
              <div className="gl-price__name">{t.name}</div>
              <div className="gl-price__amount">
                <span className="num">{typeof t.price === 'number' ? `$${t.price}` : t.price}</span>
                {t.per && <span className="per">{t.per}</span>}
              </div>
              <p className="gl-price__desc">{t.desc}</p>
              <ul className="gl-price__list">
                {t.features.map((f, j) => (
                  <li key={j}><Icon.Check/> {f}</li>
                ))}
              </ul>
              <GLButton variant={t.featured ? 'primary' : 'secondary'} style={{ width: '100%', justifyContent: 'center' }}>{t.cta}</GLButton>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="section section--tight">
      <div className="container">
        <div className="gl-cta-block">
          <div className="gl-cta-block__radar">
            <div className="ring r1"/>
            <div className="ring r2"/>
            <div className="ring r3"/>
            <div className="ring r4"/>
            <div className="sweep"/>
          </div>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <GLEyebrow>Try it free</GLEyebrow>
            <h2 style={{ marginTop: 16 }}>The leads are already <span className="accent">there.</span><br/>Stop missing them.</h2>
            <p>Set up takes three minutes. The first scored lead lands in your inbox before you finish your coffee.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <GLButton variant="primary" size="lg" iconRight={<Icon.ArrowRight/>}>Start free 14-day trial</GLButton>
              <GLButton variant="secondary" size="lg">Book a 15-minute demo</GLButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="gl-footer">
      <div className="container">
        <div className="gl-footer__grid">
          <div className="gl-footer__brand">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <GLLogo size={26}/>
              <span style={{ fontWeight: 600, fontSize: 17, letterSpacing: '-0.02em' }}>GettingLeads</span>
            </div>
            <p>Find leads in Facebook groups while you sleep. Built in Austin, Texas.</p>
          </div>
          <div className="gl-footer__col">
            <h5>Product</h5>
            <ul>
              <li><a href="#">Overview</a></li>
              <li><a href="#">How it works</a></li>
              <li><a href="#">Pricing</a></li>
              <li><a href="#">Changelog</a></li>
              <li><a href="#">API docs</a></li>
            </ul>
          </div>
          <div className="gl-footer__col">
            <h5>Company</h5>
            <ul>
              <li><a href="#">About</a></li>
              <li><a href="#">Customers</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Press kit</a></li>
            </ul>
          </div>
          <div className="gl-footer__col">
            <h5>Resources</h5>
            <ul>
              <li><a href="#">Help center</a></li>
              <li><a href="#">Status</a></li>
              <li><a href="#">Privacy</a></li>
              <li><a href="#">Terms</a></li>
            </ul>
          </div>
        </div>
        <div className="gl-footer__base">
          <span>© 2026 GettingLeads, Inc.</span>
          <span>v1.2 · All systems operational</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { Stats, Pricing, FinalCTA, Footer });
