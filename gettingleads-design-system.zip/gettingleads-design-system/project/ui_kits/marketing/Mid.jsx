/* Marketing — middle sections: HowItWorks, DashboardPreview, Features */

/* ---------- HowItWorks ---------- */
function HowItWorks() {
  return (
    <section className="section" id="how">
      <div className="container">
        <GLSectionHead
          eyebrow="How it works"
          title="Three steps. No prospecting list."
          sub="You tell us who you sell to. We watch the groups they hang out in. You wake up to a ranked queue of conversations to join."
        />
        <div className="gl-steps">
          <Step
            num="Step 1"
            title="Describe your buyer"
            desc="One paragraph. The product owner, their stack, the moment they need you. No keyword lists, no boolean queries."
            demo={<StepDemoBuyer/>}
          />
          <Step
            num="Step 2"
            title="Pick your groups"
            desc="Browse 1,800+ pre-indexed public groups, or paste a Facebook URL and we'll start monitoring within an hour."
            demo={<StepDemoGroups/>}
          />
          <Step
            num="Step 3"
            title="Wake up to leads"
            desc="Every morning, a ranked queue lands in your inbox. Open one, read the surrounding context, reply in one click."
            demo={<StepDemoInbox/>}
          />
        </div>
      </div>
    </section>
  );
}

function Step({ num, title, desc, demo }) {
  return (
    <div className="gl-step">
      <div className="gl-step__num">{num}</div>
      <div className="gl-step__title">{title}</div>
      <div className="gl-step__desc">{desc}</div>
      <div className="gl-step__demo">{demo}</div>
    </div>
  );
}

function StepDemoBuyer() {
  const text = 'ecommerce founders shipping out of US, doing $50k–$500k MRR, frustrated with their current 3PL';
  const [typed, setTyped] = useState('');
  useEffect(() => {
    let i = 0;
    const id = setInterval(() => {
      i++;
      setTyped(text.slice(0, i));
      if (i >= text.length) { clearInterval(id); }
    }, 35);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{ width: '100%', padding: '12px 14px' }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>buyer.txt</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--fg-1)', lineHeight: 1.5, minHeight: 70 }}>
        {typed}
        <span style={{ display: 'inline-block', width: 6, height: 14, background: 'var(--brand)', marginLeft: 2, verticalAlign: 'middle', animation: 'gl-pulse-dot 1s steps(2) infinite' }}/>
      </div>
    </div>
  );
}

function StepDemoGroups() {
  const groups = [
    { name: 'Shopify Founders', count: '47k', checked: true },
    { name: 'DTC CMOs',         count: '14k', checked: true },
    { name: 'Ecom Insiders',    count: '31k', checked: true },
    { name: 'Indie Hackers',    count: '54k', checked: false },
  ];
  return (
    <div style={{ width: '100%', padding: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
      {groups.map((g, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '6px 8px', background: '#fff', border: '1px solid var(--line-1)',
          borderRadius: 'var(--r-sm)', fontSize: 12,
        }}>
          <span style={{
            width: 14, height: 14, borderRadius: 3,
            background: g.checked ? 'var(--brand)' : '#fff',
            border: `1px solid ${g.checked ? 'var(--brand)' : 'var(--line-2)'}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {g.checked && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3"><path d="m5 12 4 4 10-10"/></svg>}
          </span>
          <span style={{ color: 'var(--fg-1)', fontWeight: 500 }}>{g.name}</span>
          <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-4)' }}>{g.count}</span>
        </div>
      ))}
    </div>
  );
}

function StepDemoInbox() {
  const items = [
    { score: 94, who: 'Marisa R.', text: '3PL for skincare brands…' },
    { score: 88, who: 'Aria K.',   text: 'Agency for creative testing…' },
    { score: 71, who: 'Jordan T.', text: 'Cold email warmup recs…' },
  ];
  return (
    <div style={{ width: '100%', padding: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
      {items.map((l, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '8px 10px', background: '#fff', border: '1px solid var(--line-1)',
          borderRadius: 'var(--r-sm)', fontSize: 12,
        }}>
          <ScoreChip score={l.score}/>
          <span style={{ color: 'var(--fg-1)', fontWeight: 500 }}>{l.who}</span>
          <span style={{ color: 'var(--fg-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.text}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------- DashboardPreview ---------- */
function DashboardPreview() {
  return (
    <section className="section" id="product">
      <div className="container">
        <GLSectionHead
          eyebrow="The product"
          title="A morning queue, not another tab."
          sub="Open the dashboard, work the top of the list, close the tab. Most of our customers spend under 15 minutes here a day."
        />
        <div className="gl-preview">
          <ScanLine/>
          <div className="gl-preview__frame">
            <PreviewMockup/>
          </div>
        </div>
      </div>
    </section>
  );
}

function ScanLine() {
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden',
      borderRadius: 'var(--r-lg)',
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, width: '30%', height: '100%',
        background: 'linear-gradient(90deg, transparent, rgba(21,179,108,0.12), transparent)',
        animation: 'gl-scan-line 4s var(--ease-in-out) infinite',
      }}/>
    </div>
  );
}

function PreviewMockup() {
  // Mirrors the modernized dashboard UI kit (Dashboard / Settings / Billing
  // sidebar + page header + stat strip + usage card + leads table). Same
  // visual language as the real product's Dashboard view.
  const leads = [
    { id: 1, group: 'facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'expressing need',         date: 'May 14, 2026' },
    { id: 2, group: 'facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'expressing need',         date: 'May 14, 2026' },
    { id: 3, group: 'facebook.com/groups/742421309162708', score: 86, category: 'Buying Intent', reason: 'expressing need',         date: 'May 13, 2026' },
    { id: 4, group: 'facebook.com/groups/742421309162708', score: 99, category: 'Buying Intent', reason: 'explicit purchase intent', date: 'May 13, 2026' },
  ];
  const processed = 111, limit = 5000;
  const pct = Math.round((processed / limit) * 100);

  const SideLink = ({ icon, label, active }) => (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '6px 8px', borderRadius: 6,
      background: active ? '#fff' : 'transparent',
      border: active ? '1px solid var(--line-1)' : '1px solid transparent',
      boxShadow: active ? 'var(--shadow-card)' : 'none',
      fontSize: 12, fontWeight: active ? 500 : 400,
      color: active ? 'var(--fg-1)' : 'var(--fg-2)',
      marginBottom: 1,
    }}>
      <span style={{ width: 14, height: 14, display: 'inline-flex', color: active ? 'var(--brand)' : 'var(--fg-4)' }}>{icon}</span>
      {label}
    </div>
  );

  const Stat = ({ label, value, unit, delta }) => (
    <div style={{ padding: '14px 16px', borderRight: '1px solid var(--line-1)', display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</span>
      <span style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', color: 'var(--fg-1)', fontVariantNumeric: 'tabular-nums' }}>
        {value}{unit && <span style={{ fontSize: 11, color: 'var(--fg-4)', fontWeight: 500, marginLeft: 3 }}>{unit}</span>}
      </span>
      {delta && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--brand)' }}>{delta}</span>}
    </div>
  );

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '170px 1fr', height: 460, fontSize: 12 }}>
      {/* Sidebar */}
      <aside style={{ borderRight: '1px solid var(--line-1)', padding: 14, background: '#fff', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, padding: '0 4px' }}>
          <GLLogo size={18}/>
          <span style={{ fontWeight: 600, fontSize: 13, letterSpacing: '-0.01em' }}>GettingLeads</span>
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '6px 8px' }}>Workspace</div>
        <SideLink active icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" style={{ width: 14, height: 14 }}><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>} label="Dashboard"/>
        <SideLink icon={<Icon.Filter style={{ width: 14, height: 14 }}/>} label="Settings"/>
        <SideLink icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" style={{ width: 14, height: 14 }}><rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19M6 15h4"/></svg>} label="Billing"/>

        <div style={{
          marginTop: 12, padding: '8px 10px',
          background: 'var(--green-50)', border: '1px solid var(--green-100)',
          borderRadius: 8,
          display: 'flex', alignItems: 'center', gap: 6,
          fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--green-700)',
          textTransform: 'uppercase', letterSpacing: '0.06em',
        }}>
          <span style={{
            width: 5, height: 5, borderRadius: '50%', background: 'var(--brand)',
            boxShadow: '0 0 0 3px rgba(21,179,108,0.18)',
          }}/>
          Live · monitoring
        </div>

        <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 8, paddingTop: 12, borderTop: '1px solid var(--line-1)' }}>
          <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--green-100)', border: '1px solid var(--green-100)', color: 'var(--green-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 600 }}>N</div>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15 }}>
            <span style={{ fontSize: 11, fontWeight: 500, color: 'var(--fg-1)' }}>Nina B.</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--fg-4)' }}>abraham · pro</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ padding: 18, overflow: 'hidden' }}>
        {/* Page header */}
        <div style={{ marginBottom: 12 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Overview · last 7 days</span>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--fg-1)', marginTop: 2 }}>Dashboard</div>
        </div>

        {/* Stat strip */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
          background: '#fff', border: '1px solid var(--line-1)',
          borderRadius: 8, overflow: 'hidden', marginBottom: 10,
          boxShadow: 'var(--shadow-card)',
        }}>
          <Stat label="Total leads"  value={<NumTicker to={6}/>}   delta="↑ +2 today"/>
          <Stat label="Avg score"    value={<NumTicker to={96}/>}  unit="%" delta="↑ +4 pts"/>
          <Stat label="Buying intent" value={<NumTicker to={100}/>} unit="%" delta="Stable"/>
          <Stat label="Top group"    value={<span style={{ fontSize: 13, fontWeight: 600 }}>Apartments PL</span>} delta="6 leads"/>
        </div>

        {/* Usage */}
        <div style={{ background: '#fff', border: '1px solid var(--line-1)', borderRadius: 8, padding: 14, marginBottom: 10, boxShadow: 'var(--shadow-card)' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>This month</div>
              <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em', marginTop: 2 }}>Posts processed</div>
            </div>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-3)' }}>{pct}% of plan</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', marginBottom: 8 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--fg-1)', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
              <NumTicker to={processed}/><span style={{ fontSize: 12, color: 'var(--fg-4)', fontWeight: 500, marginLeft: 2 }}> / {limit.toLocaleString()}</span>
            </span>
          </div>
          <div style={{ height: 4, background: 'var(--bg-3)', borderRadius: 999, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${pct}%`, background: 'linear-gradient(90deg, var(--green-400), var(--brand))', transition: 'width 1000ms var(--ease-out)' }}/>
          </div>
        </div>

        {/* Leads table */}
        <div style={{ background: '#fff', border: '1px solid var(--line-1)', borderRadius: 8, overflow: 'hidden', boxShadow: 'var(--shadow-card)' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--line-1)', display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em' }}>Leads</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>(6)</span>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Post','Group','Score','Reason','Date'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '7px 14px', fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 500, color: 'var(--fg-4)', textTransform: 'uppercase', letterSpacing: '0.08em', background: 'var(--bg-1)', borderBottom: '1px solid var(--line-1)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {leads.map(l => (
                <tr key={l.id} style={{ borderBottom: '1px solid var(--line-1)' }}>
                  <td style={{ padding: '8px 14px' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2, color: 'var(--brand)', fontWeight: 500, fontSize: 11 }}>
                      View post <Icon.ArrowUpRight style={{ width: 10, height: 10 }}/>
                    </span>
                  </td>
                  <td style={{ padding: '8px 14px', fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--fg-3)' }}>{l.group}</td>
                  <td style={{ padding: '8px 14px' }}>
                    <span style={{
                      display: 'inline-block', padding: '2px 7px',
                      borderRadius: 5, fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 10.5,
                      background: l.score >= 80 ? 'var(--green-50)' : 'var(--warn-50)',
                      color:      l.score >= 80 ? 'var(--green-700)' : 'var(--warn-700)',
                    }}>{l.score}%</span>
                  </td>
                  <td style={{ padding: '8px 14px', fontSize: 11, color: 'var(--fg-3)' }}>{l.reason}</td>
                  <td style={{ padding: '8px 14px', fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--fg-4)', whiteSpace: 'nowrap' }}>{l.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, badge, active, muted }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '7px 8px', borderRadius: 'var(--r-sm)',
      background: active ? '#fff' : 'transparent',
      border: active ? '1px solid var(--line-1)' : '1px solid transparent',
      boxShadow: active ? 'var(--shadow-card)' : 'none',
      fontSize: 13, color: muted ? 'var(--fg-4)' : 'var(--fg-1)',
      fontWeight: active ? 500 : 400,
      marginBottom: 2,
    }}>
      <span style={{ width: 16, height: 16, display: 'inline-flex', color: active ? 'var(--brand)' : 'var(--fg-3)' }}>
        {React.cloneElement(icon, { style: { width: 16, height: 16 }})}
      </span>
      {label}
      {badge && <span style={{
        marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10,
        background: active ? 'var(--green-50)' : 'var(--bg-2)',
        color: active ? 'var(--green-700)' : 'var(--fg-3)',
        padding: '1px 6px', borderRadius: 'var(--r-pill)',
      }}>{badge}</span>}
    </div>
  );
}

function PreviewRow({ lead, active }) {
  return (
    <div style={{
      padding: '12px 16px', borderBottom: '1px solid var(--line-1)',
      background: active ? 'var(--bg-1)' : 'transparent',
      borderLeft: active ? '2px solid var(--brand)' : '2px solid transparent',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <ScoreChip score={lead.score}/>
        <span style={{ fontWeight: 500, fontSize: 13 }}>{lead.name}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>{lead.group}</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)' }}>{lead.when}</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--fg-3)', lineHeight: 1.4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {lead.text}
      </div>
    </div>
  );
}

function Match({ label, pct }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, fontFamily: 'var(--font-mono)' }}>
      <span style={{ width: 80, color: 'var(--fg-3)' }}>{label}</span>
      <div style={{ flex: 1, height: 4, background: 'var(--bg-3)', borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: 'var(--brand)', transition: 'width 800ms var(--ease-out)' }}/>
      </div>
      <span style={{ width: 24, textAlign: 'right', color: 'var(--fg-1)' }}>{pct}</span>
    </div>
  );
}

/* ---------- Features grid ---------- */
function Features() {
  const items = [
    { icon: <Icon.Target/>,      title: 'Buyer-fit scoring',     desc: 'A single paragraph describing your brand powers every score. Tune it; the model adapts.' },
    { icon: <Icon.Sparkles/>,    title: 'Category & reason',     desc: 'Every match is tagged with the category ("Buying intent") and why it triggered ("expressing need"). No guessing.' },
    { icon: <Icon.Clock/>,       title: 'Scheduled scraping',    desc: 'Set how often we check your groups — hourly through daily — in your timezone. Runs in the background.' },
    { icon: <Icon.Lock/>,        title: 'Public groups only',    desc: 'We monitor only what is publicly accessible. No private groups, no scraping, ToS-compliant.' },
    { icon: <Icon.Users/>,       title: 'Up to 10 groups',       desc: 'Add public Facebook group URLs to your watchlist. Add, remove, or swap them out any time from Settings.' },
    { icon: <Icon.ArrowUpRight/>, title: 'Jump to the post',     desc: 'One click on any scored lead opens the original Facebook post in a new tab. Reply where they are.' },
  ];
  return (
    <section className="section">
      <div className="container">
        <GLSectionHead
          eyebrow="Built for sales teams"
          title="Quiet software that does its job."
          sub="No dashboards inside dashboards. No 14 nested menus. The features below are roughly all of them — by design."
        />
        <div className="gl-features">
          {items.map((it, i) => (
            <div key={i} className="gl-feat">
              <div className="gl-feat__icon">{it.icon}</div>
              <div className="gl-feat__title">{it.title}</div>
              <div className="gl-feat__desc" dangerouslySetInnerHTML={{ __html: it.desc }}/>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { HowItWorks, DashboardPreview, Features });
