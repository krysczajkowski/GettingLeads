# GettingLeads — Dashboard UI kit

Same screens as the real product (Dashboard / Settings / Billing) — modernized to match the landing-page brand language. The screens, data shapes, and flows are preserved from your screenshots; only the visual treatment changed.

## What changed (vs. the screenshots)

| Aspect | Real product (screenshots) | This recreation |
|---|---|---|
| Primary color | Blue | **Signal green** (matches brand) |
| Sidebar | Text-only links | Logo + icons + active card + live-monitoring pill + user block |
| Typography | System sans | **Geist** display + body, **Geist Mono** for labels & metadata |
| Page header | Simple bold title | Mono eyebrow → display title → grey sub |
| Cards | Plain border | 1px line-1 border + soft shadow, hover lifts |
| Usage card | Single progress bar | Bigger number + gradient bar + animated counter |
| Leads table | 6-column basic table | Same columns + mono table headers + filter chips + animated "View post ↗" links + colored score chips + category pills |
| Dashboard | Just usage + leads | Added 4-card stat strip (Total · Avg score · Buying intent rate · Top group), each with animated counters |
| Settings | Plain cards | Step 1 / Step 2 / Step 3 eyebrows, gradient group rows with avatars, danger-tinted Remove buttons, 3-up schedule grid |
| Billing | Plain green banner | Green-tinted banner with logo radar sweep in the corner + current-plan detail card below |

## Screens

1. **Dashboard** — stat strip → "This month / Posts processed" usage card → "Leads (N)" table with filter chips.
2. **Settings** — Brand card → Facebook Groups card → Scrape schedule card.
3. **Billing** — Active subscription banner with radar sweep + current plan card with billing details.

## Interactions

- Sidebar nav switches the view; active item is a white card with brand-green icon.
- Animated **NumTicker** counts up to value on mount and on view switch.
- **Save** buttons flash "Saved ✓" green for 1.5s on submit.
- Group **Add / Remove** updates the list and counter live.
- Filter chips on the Leads table filter by score band.
- View entrance: 280ms `fade-up` on each view switch.

## Files

- `index.html` — composes the dashboard.
- `styles.css` — modernized styles. Imports `../../colors_and_type.css`.
- `App.jsx` — `Sidebar`, `DashboardView`, `SettingsView`, `BillingView`, `App`.

## Open questions

- Should the stat strip be on every page or Dashboard-only?
- For the "Top group", I'm pulling the same Apartments PL group from your data — should this aggregate across multiple groups?
- The Billing "Current plan" detail card was invented to fill the page (your screenshot only shows the banner). Drop it if you'd rather keep Billing minimal.
- Frequency dropdown options are still a guess.
