/* GettingLeads dashboard — modernized app
 * Same screens as the real product (Dashboard / Settings / Billing) with
 * the brand's visual language applied. Data shapes preserved.
 */

const { useState, useEffect, useMemo } = React;

/* ===== Logo + Icons ================================================= */
function GLLogo({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="13.5" stroke="#15B36C" strokeWidth="1.6" opacity="0.25"/>
      <circle cx="16" cy="16" r="8.5"  stroke="#15B36C" strokeWidth="1.6" opacity="0.5"/>
      <path d="M16 16 L16 2.5 A13.5 13.5 0 0 1 27.7 9.25 Z" fill="#15B36C" fillOpacity="0.18"/>
      <path d="M16 2.5 A13.5 13.5 0 0 1 27.7 9.25" stroke="#15B36C" strokeWidth="1.8" strokeLinecap="round"/>
      <circle cx="16" cy="16" r="2.4" fill="#15B36C"/>
      <circle cx="23.4" cy="7.4" r="2.1" fill="#15B36C"/>
    </svg>
  );
}
const I = {
  Dash:    (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>,
  Cog:     (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3h.1a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7v.1a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1Z"/></svg>,
  Card:    (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19M6 15h4"/></svg>,
  Users:   (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="8" r="4"/><path d="M1 21a8 8 0 0 1 16 0"/><path d="M17 4a4 4 0 0 1 0 8"/></svg>,
  Arrow:   (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17 17 7M8 7h9v9"/></svg>,
  Check:   (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m20 6-11 11-5-5"/></svg>,
  Plus:    (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  TrendUp: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="m3 17 6-6 4 4 8-8"/><path d="M17 7h4v4"/></svg>,
  Spark:   (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8"/></svg>,
};

/* ===== Number ticker ================================================ */
function NumTicker({ to, duration = 900, format = (n) => Math.round(n).toLocaleString() }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(eased * to);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <>{format(val)}</>;
}

/* ===== Sidebar ====================================================== */
function Sidebar({ view, setView }) {
  const Item = ({ id, label, icon }) => (
    <a
      className={`gd-side__link ${view === id ? 'active' : ''}`}
      onClick={(e) => { e.preventDefault(); setView(id); }}
      href="#"
    >
      <span className="ico">{icon}</span>
      {label}
    </a>
  );
  return (
    <aside className="gd-side">
      <div className="gd-side__brand"><GLLogo size={22}/> GettingLeads</div>

      <div className="gd-side__head">Workspace</div>
      <div className="gd-side__group">
        <Item id="dashboard" label="Dashboard" icon={<I.Dash style={{ width: 16, height: 16 }}/>}/>
        <Item id="settings"  label="Settings"  icon={<I.Cog style={{ width: 16, height: 16 }}/>}/>
        <Item id="billing"   label="Billing"   icon={<I.Card style={{ width: 16, height: 16 }}/>}/>
      </div>

      <div className="gd-side__live">
        <span className="dot"/> Live · monitoring
      </div>

      <div className="gd-side__foot">
        <div className="gd-side__avatar">N</div>
        <div className="gd-side__user">
          <span className="name">Nina B.</span>
          <span className="org">abraham · pro</span>
        </div>
      </div>
      <button className="gd-side__signout">Sign out</button>
    </aside>
  );
}

/* ===== Dashboard view ============================================== */
function DashboardView() {
  // Data preserved from your screenshot
  const leads = [
    { id: 1, group: 'https://www.facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'expressing need',         date: 'May 14, 2026' },
    { id: 2, group: 'https://www.facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'expressing need',         date: 'May 14, 2026' },
    { id: 3, group: 'https://www.facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'expressing need',         date: 'May 13, 2026' },
    { id: 4, group: 'https://www.facebook.com/groups/742421309162708', score: 86, category: 'Buying Intent', reason: 'expressing need',         date: 'May 13, 2026' },
    { id: 5, group: 'https://www.facebook.com/groups/742421309162708', score: 98, category: 'Buying Intent', reason: 'explicit purchase intent', date: 'May 13, 2026' },
    { id: 6, group: 'https://www.facebook.com/groups/742421309162708', score: 99, category: 'Buying Intent', reason: 'explicit purchase intent', date: 'May 13, 2026' },
  ];

  const processed = 111, limit = 5000;
  const pct = Math.round((processed / limit) * 100);

  const [filter, setFilter] = useState('all');

  const visible = useMemo(() => {
    if (filter === '90+') return leads.filter(l => l.score >= 90);
    if (filter === '80-89') return leads.filter(l => l.score >= 80 && l.score < 90);
    return leads;
  }, [filter, leads]);

  const trunc = (url) => url.replace(/^https?:\/\/(www\.)?/, '') ;

  const avgScore = Math.round(leads.reduce((s, l) => s + l.score, 0) / leads.length);

  const scoreBand = (s) => s >= 80 ? 'hot' : s >= 50 ? 'warm' : 'cool';

  return (
    <div className="gd-view">
      <div className="gd-page-head">
        <span className="gd-page-eyebrow">Overview · last 7 days</span>
        <h1 className="gd-page-title">Dashboard</h1>
        <p className="gd-page-sub">A live look at every lead matched against your brand.</p>
      </div>

      {/* Stat strip */}
      <div className="gd-stats">
        <div className="gd-stat">
          <span className="gd-stat__label">Total leads</span>
          <span className="gd-stat__value"><NumTicker to={leads.length}/></span>
          <span className="gd-stat__delta"><I.TrendUp style={{ width: 12, height: 12 }}/> +2 today</span>
        </div>
        <div className="gd-stat">
          <span className="gd-stat__label">Avg score</span>
          <span className="gd-stat__value"><NumTicker to={avgScore}/><span className="unit">%</span></span>
          <span className="gd-stat__delta"><I.TrendUp style={{ width: 12, height: 12 }}/> +4 pts vs last week</span>
        </div>
        <div className="gd-stat">
          <span className="gd-stat__label">Buying intent rate</span>
          <span className="gd-stat__value"><NumTicker to={100}/><span className="unit">%</span></span>
          <span className="gd-stat__delta flat">Stable</span>
        </div>
        <div className="gd-stat">
          <span className="gd-stat__label">Top group</span>
          <span className="gd-stat__value" style={{ fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em' }}>Apartments PL</span>
          <span className="gd-stat__delta flat">6 leads</span>
        </div>
      </div>

      {/* Usage progress */}
      <div className="gd-card gd-card--hover">
        <div className="gd-card__head gd-card__head--no-mb">
          <div>
            <span className="gd-eyebrow">This month</span>
            <h2 className="gd-card__title" style={{ marginTop: 4 }}>Posts processed</h2>
          </div>
          <span className="gd-usage__pct">{pct}% of plan</span>
        </div>
        <div className="gd-usage__row" style={{ marginTop: 18 }}>
          <span className="gd-usage__count"><NumTicker to={processed}/><span className="of"> / {limit.toLocaleString()}</span></span>
        </div>
        <div className="gd-usage__bar"><div style={{ width: `${pct}%` }}/></div>
      </div>

      {/* Leads table */}
      <div className="gd-card gd-leads-card">
        <div className="gd-leads-card__head">
          <h2 className="gd-card__title">Leads <span className="count">({visible.length})</span></h2>
          <div className="gd-leads-card__filter">
            <span className={`gd-chip ${filter === 'all'   ? 'active' : ''}`} onClick={() => setFilter('all')}>All <span className="count">{leads.length}</span></span>
            <span className={`gd-chip ${filter === '90+'   ? 'active' : ''}`} onClick={() => setFilter('90+')}>Score 90+ <span className="count">{leads.filter(l => l.score >= 90).length}</span></span>
            <span className={`gd-chip ${filter === '80-89' ? 'active' : ''}`} onClick={() => setFilter('80-89')}>80–89 <span className="count">{leads.filter(l => l.score >= 80 && l.score < 90).length}</span></span>
          </div>
        </div>
        <table className="gd-table">
          <thead>
            <tr>
              <th>Post</th>
              <th>Group</th>
              <th>Score</th>
              <th>Category</th>
              <th>Reason</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {visible.map(l => (
              <tr key={l.id}>
                <td>
                  <a className="gd-row-link" href="#" onClick={(e) => e.preventDefault()}>
                    View post <I.Arrow className="arrow"/>
                  </a>
                </td>
                <td><span className="gd-group-url">{trunc(l.group)}</span></td>
                <td><span className={`gd-pct ${scoreBand(l.score)}`}>{l.score}%</span></td>
                <td><span className="gd-category">{l.category}</span></td>
                <td><span className="gd-reason">{l.reason}</span></td>
                <td><span className="gd-date">{l.date}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ===== Settings view ================================================ */
function SettingsView() {
  const [brandName, setBrandName] = useState('Abraham');
  const [brandDesc, setBrandDesc] = useState('I am looking for an apartment / room to live in.');
  const [brandSaved, setBrandSaved] = useState(false);

  const [groups, setGroups] = useState(['https://www.facebook.com/groups/742421309162708']);
  const [newGroup, setNewGroup] = useState('');
  const MAX_GROUPS = 10;

  const [frequency, setFrequency] = useState('Once a day');
  const [startTime, setStartTime] = useState('1:00 PM');
  const [timezone, setTimezone] = useState('Europe/Warsaw');
  const [schedSaved, setSchedSaved] = useState(false);

  const flashSave = (setter) => { setter(true); setTimeout(() => setter(false), 1500); };

  const addGroup = () => {
    const url = newGroup.trim();
    if (!url) return;
    if (groups.length >= MAX_GROUPS) return;
    setGroups([...groups, url]);
    setNewGroup('');
  };
  const removeGroup = (i) => setGroups(groups.filter((_, idx) => idx !== i));

  return (
    <div className="gd-view">
      <div className="gd-page-head">
        <span className="gd-page-eyebrow">Configuration</span>
        <h1 className="gd-page-title">Settings</h1>
        <p className="gd-page-sub">Tell us who you sell to, which groups to watch, and when to check them.</p>
      </div>

      {/* Brand */}
      <form className="gd-card" onSubmit={(e) => { e.preventDefault(); flashSave(setBrandSaved); }}>
        <div className="gd-card__head">
          <div>
            <span className="gd-eyebrow">Step 1</span>
            <h2 className="gd-card__title" style={{ marginTop: 4 }}>Brand</h2>
          </div>
        </div>
        <p className="gd-card__sub" style={{ marginTop: -10 }}>Describe your brand so the AI knows what leads to look for.</p>

        <div className="gd-field">
          <label className="gd-field__label">Brand name</label>
          <input className="gd-input" value={brandName} onChange={(e) => setBrandName(e.target.value)}/>
        </div>
        <div className="gd-field">
          <label className="gd-field__label">Brand description</label>
          <textarea className="gd-textarea" value={brandDesc} onChange={(e) => setBrandDesc(e.target.value)} placeholder="e.g. We sell 3PL services to ecommerce founders shipping out of the US…"/>
          <span className="gd-field__hint">One paragraph is plenty — be specific about who, what, and the moment they need you.</span>
        </div>

        <button type="submit" className={`gd-btn gd-btn--primary ${brandSaved ? 'gd-btn--saved' : ''}`}>
          {brandSaved ? <><I.Check/> Saved</> : 'Save'}
        </button>
      </form>

      {/* Facebook Groups */}
      <div className="gd-card">
        <div className="gd-card__head">
          <div>
            <span className="gd-eyebrow">Step 2</span>
            <h2 className="gd-card__title" style={{ marginTop: 4 }}>Facebook Groups</h2>
          </div>
          <span className="gd-meta" style={{ margin: 0 }}>{groups.length} / {MAX_GROUPS} groups</span>
        </div>
        <p className="gd-card__sub" style={{ marginTop: -10 }}>Add public Facebook groups to monitor for leads.</p>

        <div className="gd-group-list">
          {groups.map((g, i) => (
            <div className="gd-group-row" key={i}>
              <div className="gd-group-row__left">
                <span className="gd-group-row__ico"><I.Users/></span>
                <a className="gd-group-url-link" href={g} target="_blank" rel="noreferrer" onClick={(e) => e.preventDefault()}>{g}</a>
              </div>
              <button className="gd-remove" onClick={() => removeGroup(i)}>Remove</button>
            </div>
          ))}
        </div>

        <div className="gd-add-row">
          <input
            className="gd-input"
            placeholder="https://facebook.com/groups/…"
            value={newGroup}
            onChange={(e) => setNewGroup(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addGroup(); } }}
          />
          <button className="gd-btn gd-btn--primary" onClick={addGroup} disabled={groups.length >= MAX_GROUPS}>
            <I.Plus/> Add
          </button>
        </div>
      </div>

      {/* Scrape Schedule */}
      <form className="gd-card" onSubmit={(e) => { e.preventDefault(); flashSave(setSchedSaved); }}>
        <div className="gd-card__head">
          <div>
            <span className="gd-eyebrow">Step 3</span>
            <h2 className="gd-card__title" style={{ marginTop: 4 }}>Scrape schedule</h2>
          </div>
        </div>
        <p className="gd-card__sub" style={{ marginTop: -10 }}>Choose when your groups are checked for new leads.</p>

        <div className="gd-field-grid">
          <div className="gd-field">
            <label className="gd-field__label">Frequency</label>
            <select className="gd-select" value={frequency} onChange={(e) => setFrequency(e.target.value)}>
              <option>Every hour</option>
              <option>Every 3 hours</option>
              <option>Every 6 hours</option>
              <option>Twice a day</option>
              <option>Once a day</option>
            </select>
          </div>
          <div className="gd-field">
            <label className="gd-field__label">Start time</label>
            <select className="gd-select" value={startTime} onChange={(e) => setStartTime(e.target.value)}>
              {['9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','6:00 PM','9:00 PM'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="gd-field">
            <label className="gd-field__label">Timezone</label>
            <select className="gd-select" value={timezone} onChange={(e) => setTimezone(e.target.value)}>
              {['America/Los_Angeles','America/New_York','Europe/London','Europe/Warsaw','Europe/Berlin','Asia/Singapore','Asia/Tokyo'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>

        <button type="submit" className={`gd-btn gd-btn--primary ${schedSaved ? 'gd-btn--saved' : ''}`}>
          {schedSaved ? <><I.Check/> Saved</> : 'Save'}
        </button>
      </form>
    </div>
  );
}

/* ===== Billing view ================================================= */
function BillingView() {
  return (
    <div className="gd-view">
      <div className="gd-page-head">
        <span className="gd-page-eyebrow">Plan & invoices</span>
        <h1 className="gd-page-title">Billing</h1>
        <p className="gd-page-sub">Manage your subscription, payment method, and history.</p>
      </div>

      <div className="gd-billing-banner">
        <div className="gd-billing-banner__radar">
          <div className="ring r1"/>
          <div className="ring r2"/>
          <div className="ring r3"/>
          <div className="ring r4"/>
          <div className="sweep"/>
        </div>
        <div className="gd-billing-banner__ico"><I.Check style={{ width: 22, height: 22, strokeWidth: 2.4 }}/></div>
        <h2 className="gd-billing-banner__title">Your subscription is active.</h2>
        <p className="gd-billing-banner__sub">Manage your subscription through the customer portal.</p>
        <button className="gd-btn gd-btn--primary" onClick={(e) => e.preventDefault()}>
          Manage Subscription <I.Arrow/>
        </button>
      </div>

      <div className="gd-card">
        <div className="gd-card__head">
          <div>
            <span className="gd-eyebrow">Current plan</span>
            <h2 className="gd-card__title" style={{ marginTop: 4 }}>Pro</h2>
          </div>
          <button className="gd-btn gd-btn--ghost">Change plan</button>
        </div>
        <div className="gd-billing-grid">
          <div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Monthly cost</span><span className="gd-billing-row__v">$49.00</span></div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Posts processed</span><span className="gd-billing-row__v">111 / 5,000</span></div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Groups monitored</span><span className="gd-billing-row__v">1 / 10</span></div>
          </div>
          <div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Next renewal</span><span className="gd-billing-row__v">June 14, 2026</span></div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Payment method</span><span className="gd-billing-row__v">Visa · 4242</span></div>
            <div className="gd-billing-row"><span className="gd-billing-row__k">Billed to</span><span className="gd-billing-row__v">nina@abraham.dev</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===== App shell ==================================================== */
function App() {
  const [view, setView] = useState('dashboard');
  return (
    <div className="gd-app">
      <Sidebar view={view} setView={setView}/>
      <main className="gd-main">
        {view === 'dashboard' && <DashboardView/>}
        {view === 'settings'  && <SettingsView/>}
        {view === 'billing'   && <BillingView/>}
      </main>
    </div>
  );
}

Object.assign(window, { App });
