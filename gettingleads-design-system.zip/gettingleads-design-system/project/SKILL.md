---
name: gettingleads-design
description: Use this skill to generate well-branded interfaces and assets for GettingLeads (a B2B SaaS that monitors public Facebook groups and surfaces AI-scored lead opportunities), either for production or throwaway prototypes/mocks/landing pages/decks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

The system here is split into:
- `README.md` — brand context, voice, visual foundations, iconography.
- `colors_and_type.css` — all design tokens as CSS custom properties (color, type, spacing, radius, shadow, motion).
- `assets/` — logos, radar backdrop.
- `preview/` — design-system cards showing every token + component in isolation.
- `ui_kits/marketing/` — landing page UI kit (Nav, Hero, TrustMarquee, HowItWorks, DashboardPreview, Features, Stats, Pricing, FinalCTA, Footer).
- `ui_kits/dashboard/` — lead-inbox dashboard UI kit (Sidebar, Topbar, FilterRow, LeadList, LeadDetail, Composer).

If creating visual artifacts (slides, mocks, throwaway prototypes, landing pages, etc), copy assets out (logos from `assets/`, tokens via `colors_and_type.css`) and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Core brand reminders before you start:
- **White background.** Bright, technical, motion-rich. Closer to Linear/Vercel/Cal.com than HubSpot/Salesforce.
- **One brand color** — signal green (`--brand: #15B36C`). Use restraint; green only where you want the eye.
- **Geist + Geist Mono.** Body in sans, metadata in mono. Reserve `Instrument Serif italic` for one editorial moment per page.
- **Sentence case** everywhere. **No emoji.** Lucide icons.
- **Motion is first-class** — radar sweep, scan lines, number tickers, marquee, fade-up stagger. Use `--ease-out` by default, 200ms duration.
- **Voice: confident, direct, slightly understated.** Never "revolutionize," "leverage," or "unlock."

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
